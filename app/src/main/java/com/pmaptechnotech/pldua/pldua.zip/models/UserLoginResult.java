package com.pmaptechnotech.pldua.models;

import java.util.List;

/**
 * Created by intel on 12-02-18.
 */

public class UserLoginResult {

    public boolean is_success;
    public String msg;
    public List<User> user;
}
