package com.pmaptechnotech.pldua.models;

/**
 * Created by intel on 02-03-18.
 */

public class DeptListInput {
    public String dept_type;

    public DeptListInput(String dept_type) {
        this.dept_type = dept_type;
    }
}
