package com.pmaptechnotech.pldua.activities;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.pmaptechnotech.pldua.R;

public class AgricultureDeptInfoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agriculture_dept_info);
    }
}
