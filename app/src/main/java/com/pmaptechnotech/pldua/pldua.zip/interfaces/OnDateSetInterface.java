package com.pmaptechnotech.pldua.interfaces;

/**
 * Created by admin on 17/02/2017.
 */
public interface OnDateSetInterface {
  void OnDateSet(String date);
}
