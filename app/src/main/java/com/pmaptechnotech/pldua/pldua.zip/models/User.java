package com.pmaptechnotech.pldua.models;

/**
 * Created by Admin on 1/7/2018.
 */

public class User {
    public String user_name="";
    public String user_mobile_number="";

}
