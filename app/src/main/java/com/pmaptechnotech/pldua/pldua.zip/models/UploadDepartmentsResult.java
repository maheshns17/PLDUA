package com.pmaptechnotech.pldua.models;

import java.util.List;

/**
 * Created by intel on 01-03-18.
 */

public class UploadDepartmentsResult {

    public boolean is_success;
    public String msg;
    public List<User> user;
}
