package com.pmaptechnotech.pldua.models;

import java.util.List;

/**
 * Created by intel on 03-03-18.
 */

public class MushroomResult {

    public boolean is_success;
    public String msg;
    public List<User> user;
}
