package com.pmaptechnotech.pldua.models;

import java.util.List;

/**
 * Created by intel on 10-02-18.
 */

public class UserRegisterResult {

    public boolean is_success;
    public String msg;
    public List<User> user;
}
